pwd
ls
cd ..
pwd
ls
pwd
