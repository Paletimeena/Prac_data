#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *prev;
	struct node *next;
	

};
typedef struct node NODE;
NODE *root=NULL;
void create(int num)
{
	if(root ==NULL)
	{


	}


}

int main()
{
	create(25);





return 0;
}
