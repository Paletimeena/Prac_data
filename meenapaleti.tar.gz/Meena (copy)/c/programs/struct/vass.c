#include<stdio.h>
int main()
{
	int v1;
	char ch;
	v1=65530;
	ch=v1;
	printf("%d\n",ch);

return 0;
}
