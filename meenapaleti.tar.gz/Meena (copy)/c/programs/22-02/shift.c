#include<stdio.h>
int main()
{

char val,res;
val=20;
res=(val<<4);
printf("shifted %d \n",res);
val=15;
res=(val<<3);
printf("shifted %d \n",res);
val=75;
res=(val<<1);
printf("shifted %d \n",res);
}
