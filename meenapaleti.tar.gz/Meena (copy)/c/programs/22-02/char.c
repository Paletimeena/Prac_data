#include<stdio.h>
int main()
{
char ch1 ,ch2 ;
int res;
ch1=100;
ch2=150;
res=ch1+ch2;
printf("%d \n",res);
return 0;


}
