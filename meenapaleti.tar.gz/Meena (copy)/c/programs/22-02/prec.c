#include<stdio.h>
int main()
{
	int myeq=3+4*5;
	printf("3+4*5 is %d \n",myeq);
	int v1=(3+4)*5;
	printf("(3+4)*5 is %d \n",v1);
	int v2=20 * 6/5;
	printf("20*6/5 is %d \n",v2);
	int v3 =2+5/6*2+(3/7);
	printf("2+3/6*2+(3/7) is %d \n",v3);
	return 0;
}

