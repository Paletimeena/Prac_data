#include<stdio.h>
int main()
{
	int v1,v2;
	v1=100;
	v2=200;
	if(v2 > v1)
	{
		printf("hey r u ready");
		printf("v2 > v1");
	}
	else
		printf("v2 is not grater than v1");

	if(v1=0)
		printf("v1 is %d \n",v1);
	else
		printf("sorry \n");
	
	if(100)
		printf(" 100 ya non zero value\n");
	else
		printf("sorry i ll not excute\n");
	
	if(-100)
		printf("-100 is still non zero value\n");
	else
		printf("sorry");
	
	
	return 0;

	
}
