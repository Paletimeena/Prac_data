#include<stdio.h>
int main()
{

int v1 , v2 , sum;
sum = (v1=10, v2=50, v1+v2 , v1 =5 , v2 = 200);
printf("%d \n",sum);
return 0;
}
