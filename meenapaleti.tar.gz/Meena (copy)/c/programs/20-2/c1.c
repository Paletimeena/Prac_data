#include<stdio.h>
int main()
{
	printf("hello votary \n");
	return(0);
}
