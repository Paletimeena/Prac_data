#include<stdio.h>
 int main()
{
	char ch='a';
	int v1=1000;
	float v2=1025.2456;
	//long v3= 5451215412341231;
	printf("%d %d %d",sizeof(ch),sizeof(v1),sizeof(v2));
	return 0;
}
