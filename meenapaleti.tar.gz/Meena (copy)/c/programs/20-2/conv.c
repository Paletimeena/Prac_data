#include<stdio.h>
int main()
{
	int v1;
	printf("enter the no");
	scanf("%d")
	printf("%o %d %x \n",v1,v1,v1);
	v1 = 0123;
	printf("%o %d %x \n",v1,v1,v1);
	v1 = 0x123;
	printf("%o %d %x \n",v1,v1,v1);
	return 0;
}
