#include<stdio.h>
#include<stdlib.h>
struct node
	{
	int data;
	struct node* link;
	};

int main()
	{
	
	struct node* head = NULL;
	

	}
