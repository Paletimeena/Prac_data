#include<stdio.h>
int main()
{
int res;
res =  10 / -3;
printf("result is %d\n",res);
return 0;
}

