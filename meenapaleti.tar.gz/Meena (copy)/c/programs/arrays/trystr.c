#include<stdio.h>
int main()
{
  char arr[10]={'a','b','c','d','e','\0'};
	int i=0;
	printf("%s",arr);
/***	while(arr[i] !='\0')
	{
		printf("%c",arr[i]);
		i++;
	}***/
	printf("\n");
return 0;
}
