#include<stdio.h>
#include<string.h>
int main()
{
	char str1[]="meena";
	char str2[]="mee";
	int len;
	len = strlen(str1);
	printf("str1 len : %d\n",len);
//	strcpy(str2,str1);
	int cmp;
	printf("str1: %s\n",str1);
	printf("str2 : %s\n",str2);
//	str2[]="paleti";
//	printf("str1 len : %d\n",strlen(str1));
//	printf("str2 len : %d\n",strlen(str2));

//	strcat(str2,str1);
//	printf("strcat : %s\n",str2);
//	cmp=strcmp(str2,str1);
//	printf(" compared %d\n",cmp);
return 0;


}
