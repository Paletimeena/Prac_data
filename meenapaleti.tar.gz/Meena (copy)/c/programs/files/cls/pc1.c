#include<stdio.h>
#define NAME "MY NAME IS MEENA.P\n"

void main()
{
	printf(NAME);

}
