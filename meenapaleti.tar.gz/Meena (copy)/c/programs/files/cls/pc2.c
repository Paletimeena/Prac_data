#include<stdio.h>
#define EXP(V1,V2) V1*V2

void main()
{
	int V1 =10;
	int V2 = 20;
	printf("%d\n",EXP(V1,V2));
	



}
