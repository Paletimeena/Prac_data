#include<stdio.h>
void main()
{
	int  num,res=1,i;
	printf("enter the number\n");
	scanf("%d",&num);
	for(i=1;i<=num;i++)
	{
		res =i*res;
	
	}
	printf("faactyorial is %d\n",res);









}
