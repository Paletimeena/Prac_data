#include<stdio.h>
void main()
{
	int val=10;
	int i=0;
	do 
	{
	printf("%d\n",i);
	i++;
	}while(i<=val);
}
