#include<stdio.h>
void main()
{
	int val=10;
	int i=0;
	while(i<=val)
	{
	printf("%d\n",i);
	i++;
	}
}
