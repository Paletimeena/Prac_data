#include<stdio.h>
#include<math.h>
int main()
{
char x;
int a=2;

long int y;
y=sizeof(x);
printf("%ld\n",y);
y=y*8;
y=y-1;
printf("range %ld",y);
*/
return 0;


}
