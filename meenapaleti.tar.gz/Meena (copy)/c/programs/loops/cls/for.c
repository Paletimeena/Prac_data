#include<stdio.h>
void main()
{
	int val=10;
	int i=0;
	for(i=0;i<=val;i++)
	{
	printf("%d\n",i);
	}
}
