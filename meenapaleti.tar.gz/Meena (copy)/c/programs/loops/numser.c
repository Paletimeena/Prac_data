#include<stdio.h>
int main()
{
	int i;
	for(i = 0; i <= 100; i++)
	{
		printf("%d\n",i);
	}
return 0;
}
