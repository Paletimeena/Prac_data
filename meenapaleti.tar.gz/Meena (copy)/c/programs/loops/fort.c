#include<stdio.h>
int main()
{
	char ch = 0;
	for (; ch >= 0; ch++);
	printf("%d\n",ch);


}
