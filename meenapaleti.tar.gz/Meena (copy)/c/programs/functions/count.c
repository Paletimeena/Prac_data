#include<stdio.h>
void maain()
{
	int num,op,count,res,i,j;
	num=1643;
	while(num)

	{


	}




}
