#include<stdio.h>
int main()
{
	printf("size of integer is %d\n",sizeof(int));
	printf("Size of character is %d\n",sizeof(char));
	printf("size of Float is %d\n",sizeof(float));
	printf("Size of Double is %d\n",sizeof(double));
	
	printf("size of Unsigned integer is %d\n",sizeof(unsigned int));
	printf("Size of Unsigned character is %d\n",sizeof(unsigned char));
	printf("size of Short int is %d\n",sizeof(short int));
	printf("Size of Long int is %d\n",sizeof(long int));
	printf("Size of Long double is %d\n",sizeof(long double));
}
