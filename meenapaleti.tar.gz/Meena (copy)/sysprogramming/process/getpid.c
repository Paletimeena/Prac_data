#include<stdio.h>
int main()
{
  printf("Iam the process with procees -id %d\n",getpid());



return 0;
}
