dict={"name":"vinay","age":7}
print dict
dict['mble']=99988
print dict
print dict
dict['flt']=12.5
print dict
