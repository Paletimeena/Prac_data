#!/usr/bin/python
for letter in "python":
	if letter =='h': 
		print "found"
		pass
	print letter
