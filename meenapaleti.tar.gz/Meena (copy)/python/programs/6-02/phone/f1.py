#1/usr/lib/python
def fun1():
	print "file 1 is called"
fun1()
