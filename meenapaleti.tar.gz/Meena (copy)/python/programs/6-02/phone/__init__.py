
from f1 import fun1
from f2 import fun2
from f3 import fun3
