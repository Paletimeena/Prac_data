#!/usr/lib/python
def fun2():
	print "fun2 is called"
fun2()
