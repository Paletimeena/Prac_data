#!usr/lib/python
def fun3():
	print "fun3 is called"
fun3()
