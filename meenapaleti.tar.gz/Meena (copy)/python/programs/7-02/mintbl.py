#!/usr/bin/python
x=input("enter the least number")
y=input("enter the max number")
for i in range(x,y+1):
	for j in range(1,11):
		print i*j,
	print ""








