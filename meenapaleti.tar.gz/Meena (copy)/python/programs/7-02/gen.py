def myvalue(data):
	for i in range (1,10):
		print data[i]
		yield data[i]

myvalue("my name is meena")
print data[i]
