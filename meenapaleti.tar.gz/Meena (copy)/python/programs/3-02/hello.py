#!/usr/bin/python
print "hello world"
