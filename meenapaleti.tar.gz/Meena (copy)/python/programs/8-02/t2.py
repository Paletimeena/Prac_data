def max_mul(l1,l2,l3,l4,l5):
	lis=[]
#	print len(argv)
#	print l1
#	for i in range(1,6):
	lis.append(l1)
	lis.append(l2)
	lis.append(l3)
	lis.append(l4)
	lis.append(l5)
	print lis
	lis=sorted(lis)
	total=lis[-1]*lis[-2]
	print total
#lis=[1,5,8,6,3]'''
#lis=[]
max_mul(1,8,3,4,5)
