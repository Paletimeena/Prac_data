#!/usr/bin/python
def pots():
 
	print "post file is called"


pots()
