#!/usr/bin/python

from pots import pots
from isdn import isdn
from g3 import g3

