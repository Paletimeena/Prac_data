#!/usr/bin/python
def g3():
	print "g3 file is called"
g3()
