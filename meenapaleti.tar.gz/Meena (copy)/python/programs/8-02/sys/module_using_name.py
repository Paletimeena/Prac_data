#!usr/bin/python

if(__name__=='__main__'):
	print 'in script'
else:
	print "in interaction"
