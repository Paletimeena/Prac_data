#!/usr/bin/python
V1=45
V2=56
print "v1",bin(V1),V1
print "v2",bin(V2),V2
print "v1&V2",V1 & V2
print "v1|V2",V1 | V2
print "v1 ^ V2",V1 ^ V2
print "~V1",~ V1
print "~V2",~ V2
print "v1<<1",V1<<1
print "v1>>2",V1>>2
V1=034
V2=045
print "v1",bin(V1),V1
print "v2",bin(V2),V2
print "v1&V2",V1 & V2
print "v1|V2",V1 | V2
print "v1 ^ V2",V1 ^ V2
print "~V1",~ V1
print "~V2",~ V2
print "v1<<1",V1<<1
print "v1>>2",V1>>2

V1=0xAB
V2=0x89
print "v1",bin(V1),V1
print "v2",bin(V2),V2
print "v1&V2",V1 & V2
print "v1|V2",V1 | V2
print "v1 ^ V2",V1 ^ V2
print "~V1",~ V1
print "~V2",~ V2
print "v1<<1",V1<<1
print "v1>>2",V1>>2


