x=10
y=5
print 'x value is'+ str(x)
print 'x value is %s',x
print 'x value is %s and y value is %s',(x,y)
