import stmain
print __name__