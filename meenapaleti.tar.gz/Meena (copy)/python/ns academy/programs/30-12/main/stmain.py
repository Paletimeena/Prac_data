def print_name(name):
    print name
print __name__

if __name__ == "__main__":
    print_name('calling main')

