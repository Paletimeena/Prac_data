name=raw_input("enter the string:  ")
reverse=name[::-1]
print reverse
if name==reverse:
    print 'palindrome'
else:
    print 'not palindrome'
    

#list (reversed(name))
#print list
