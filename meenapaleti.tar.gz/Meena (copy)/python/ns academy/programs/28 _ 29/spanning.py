big="""my name is meena.p
 i want to be python developer
 so i am learning python right now."""

