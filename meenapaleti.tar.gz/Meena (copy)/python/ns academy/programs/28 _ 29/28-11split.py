name = 'paletimeena|bellari|fvev'
print name.split('|')
