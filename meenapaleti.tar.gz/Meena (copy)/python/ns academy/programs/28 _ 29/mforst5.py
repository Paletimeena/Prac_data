for numb in range(1,10):
    if(numb%2==0):
        print 'number is even',numb
    else :
        print 'number is odd',numb
