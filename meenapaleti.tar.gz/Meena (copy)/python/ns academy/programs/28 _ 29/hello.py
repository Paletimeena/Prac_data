print "Hello World"
