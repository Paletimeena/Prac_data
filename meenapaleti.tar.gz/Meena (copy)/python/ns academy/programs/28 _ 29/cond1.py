x=100
if x:
    print 'x is true'
else :
    print 'x is false'
