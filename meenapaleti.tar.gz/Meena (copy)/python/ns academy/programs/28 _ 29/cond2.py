#x=1
x=0
if x==0:
    y=1
    if y:
        print 'x is false and y is true'
    else :
        print 'x is false and y is false'
        
else:
    print 'x is true and y not available'
