numbs=[1,2,3]
for numb in numbs:
    print numb**2
