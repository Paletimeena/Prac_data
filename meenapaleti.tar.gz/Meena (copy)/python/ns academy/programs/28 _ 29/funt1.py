#to create function
def sum(x,y):
    return x+y
print sum(10,20)

