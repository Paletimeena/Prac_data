name="paletimeena"
for x in name:
    print name[2:4]
    
i=0
while(i<len(name)):
    print name[i:]
    i=i+1
