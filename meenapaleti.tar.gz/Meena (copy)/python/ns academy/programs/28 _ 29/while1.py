x=0
while x<10:
    print x
    print 'meena'
    x=x+1
