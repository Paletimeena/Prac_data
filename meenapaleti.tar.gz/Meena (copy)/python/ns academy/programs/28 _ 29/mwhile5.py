i=1
j=1
while i<=10:
       
     while j<=5:
        if j==4:
            break
            #continue
        else:
            i+=1
            j+=1
            print i,j

    
