name=raw_input('enter the string')
i=len(name)
#print name[-1:0]

while i>0:
    #print i,name[i:10
    print name[i-1]
    reverse=name[i-1]
    i=i-1
   
