fruit=raw_input("enter fruit name\n")
if fruit=="apple":
	print"fruit is apple\n"
elif fruit=="mango":
	print"given fruit is mango"
else:
	print "given fruit is not apple nor mango\n"






    
