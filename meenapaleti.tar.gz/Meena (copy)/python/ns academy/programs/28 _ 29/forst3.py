fruits = ['banana', 'apple',  'mango']
for fruit in fruits:       
   print 'Current fruit :', fruit
