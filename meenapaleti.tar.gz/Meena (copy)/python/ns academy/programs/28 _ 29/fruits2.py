fruits=['apple','mango','orange']
for fruit in fruits:
    if fruit=='apple':
        print"its an apple"
    elif fruit=='mango':
        print "its a mango"
    else :
        print "not mango nor apple"

        
        
