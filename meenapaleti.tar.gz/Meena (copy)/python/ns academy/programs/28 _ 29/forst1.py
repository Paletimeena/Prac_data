name=raw_input('enter ypur Name ')
#repeat=raw_input('enter how many times your name should be repeated ')
x=0
while x<10:
    print x,name
    x=x+1
