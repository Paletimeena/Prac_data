x=raw_input("enter a number")
x=int(x)
if(x>0):
    print "positive"
elif x==0:
    print "zero"
else:
    print "Negative"
