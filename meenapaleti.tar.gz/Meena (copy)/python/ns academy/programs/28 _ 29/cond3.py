place=raw_input('enter the place name:  ')
if place=='bangalore':
    print 'you entered into bangalore city'
elif place=='pune':
    print 'you entered into pune city'
elif place=='hyderbadp':
     print 'you entered into hyderbad city'
elif place=='chennai':
    print 'you entered into chennai city'
else:
    print 'you entered city is not found please enter proper place'
