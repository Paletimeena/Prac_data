print 'hello meennaaa'
x=0
if x:
    y=2
    if y:
        print 'block 2'
        print 'block 1'
else:
        print 'block 0'






    
