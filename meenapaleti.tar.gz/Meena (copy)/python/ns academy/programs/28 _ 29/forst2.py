for letter in 'Python':    
   print 'Current Letter :', letter
