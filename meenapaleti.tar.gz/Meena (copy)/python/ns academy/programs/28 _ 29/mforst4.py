#fabonic series using for loop
a = 0
b = 1
for c in range(1,10):
    print (a)
    n = a + b
    a = b
    b = n
print ("")
