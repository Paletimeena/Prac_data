x=input("enter the number")
print x
