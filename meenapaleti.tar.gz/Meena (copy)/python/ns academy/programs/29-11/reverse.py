#write a python program to reverse the string
# meenapaleti
x=raw_input("enter the name")
x=x[::-1]
print x
