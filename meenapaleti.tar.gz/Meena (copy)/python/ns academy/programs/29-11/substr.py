mainstring=raw_input("enter the string ")
substring=raw_input("enter the sub string need to find")
if mainstring.find(substring)!=-1:
    print substring,"is found"
else:
    print substring,"is not found"
