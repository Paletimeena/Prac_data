#WAP to find vowles or constants
x=raw_input("enter the charater")
if x=='a' or x=='e' or x=='i' or x=='o'or x=='u':
#if x.find('a' or 'e' or 'i'or 'o' or 'u'):
    print x,"is vowel"
else:
    print x,"is constant"
    
