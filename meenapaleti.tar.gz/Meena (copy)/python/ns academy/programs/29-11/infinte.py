while(1):
    print "true"
