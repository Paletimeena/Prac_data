#write a python program to reverse the string
x=raw_input("enter the string")
y=reversed(x)
if list(x)==list(y):
    print "palindrome"
else:
    print "not palindrome"
