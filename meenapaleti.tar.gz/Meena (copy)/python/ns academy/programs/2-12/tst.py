x='parrot'
y=1
print 'that is %y dead %s...'%(y,x)
