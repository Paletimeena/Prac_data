square=lambda x:x**2
print square(2)
print square(3)
