d={1:'hello','two':42,'blah':[1,2,3]}
print d
print d.keys()
print d.values()
print d.items()
print d[1]
print d['two']
print d['blah']
