num=[2,4,5,6,8,10]
print num
num.reverse()
print "reversed",num
add=[1,3]
num.extend(add)
print "extended 1,3",num
num.insert(2,90)
print "inserted 2 position 90",num
num.sort()
print "sorted",num
num.remove(90)
print "removed 5 ",num

