x=[1,2,3,4]
y=x
print y,'y 1st time'
z=x.append(5)
print z,'z is value'
print y,'y 2nd time'
print x,'x value'
x=x+[6,7]
print z,'z value'
print y,'y value'
print x,'x value'
