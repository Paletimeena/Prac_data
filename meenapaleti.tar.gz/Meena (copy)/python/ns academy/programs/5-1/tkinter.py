import Tkinter

class calculator():
    def __int__(self,master):
        self.master=master
        self.la










root=Tk()
my_gui=calculator(root)
mainloop()
