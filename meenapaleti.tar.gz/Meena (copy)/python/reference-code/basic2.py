#!usr/bin/python
val = 10
val = 21
val2 = 10
res = 0
res = val + val2
print res

print "Result is",res

res+= 10
print "Result is",res

res-= 10
print "Result is",res

res-= val
print "Result is",res

res-= val
print "Result is",res

res*= val
print "Result is",res

val = 10
val = 21
val2 = 10
res = val + val2
res/= val
print "Result is", res

res**= val2
print "Result is", res

val = 10
val1 = 20 
	val2 = 15
res = (val < val1) and (val1 < val2)
	print res
res = (val < val1) or (val1 < val2)
	print res

res = not(val < val1) 
	print res

	res = (val < val1) and (val1 = 15)
res = (val < val1) and (val1 = 15)
	^
	res = (val < val1) and ("JAY HIND")
	print res
	res = (val < val1) and (print ("JAY HIND"))
	res = (val < val1) and (print ("JAY HIND"))
	^
	res = (val < val1) and ("JAY HIND")
	print res
	val1=20
	val2 = 10
	res = (val1 < val2) and ("Hi")
	print res
	res = (val1 > val2) and ("Hi")
	print res
	res = "Hi"
	res = (val1 > val2) and 30
	print res
	res = (val1 > val2) and 30
	res = (val1 > val2) or 30
	print res
	res = (val1 < val2) or 30
	print res
	res = 20 and 30
	print res
	res = 20 or 30
	print res
	res = 0 or -30
	print res
	val = 200
	val1 = 300
	res = val & val1
	print res
	res = val | val1
	print res
	res = val ^ val1
	print res

	val = 200
	res = ~val
	print res
	val = 0200
	res = ~val
	print res
	val = 200
	res = val << 2
	print res
res = (val << 2)
	print res

	val = 50
res = (val << 2)
	print res

	val = 50
res = (val << 5)
	print res

	val = 500
res = (val >> 2)
	print res

	val = 5000
res = (val >> 3)
	print res
	val = 500
res = (val >> 2)
	print res

res = (res >> 2)
	print res
	val = 125
res = (val >> 1)
	print res
	val = 50000
res = (val << 5)
	print res
	val = 0x78
	val = 0x9B
	res = val & val2
	val = 0x78
	val2 = 0x78
	res = val & val2
	print res

	val = 0x78
	val2 = 0x9B
	res = val & val2
	print res

	val = 0x78
	val2 = 0x9B
	res = val | val2
	print res

	val = 0x78
	val2 = 0x9B
	res = val ^ val2
	print res
	val = 0x78
	val2 = 0x9B
	res = val ^ val2
	print res

	res = val << 2
	print res

	res = val >> 3 
	print res

	val = 0x78
res = bin(val)
	print res
	0b1111000


