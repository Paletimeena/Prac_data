#!/usr/bin/python
x = 10
y = 20
print "Hello India"
z = x + y
print "Sum of two numbers {0} and {1} is {2}".format(x,y,z)
print "Thanks"
