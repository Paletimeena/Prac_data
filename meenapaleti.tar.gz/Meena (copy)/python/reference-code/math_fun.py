#!/usr/bin/python
import math
v1 = 2.50
v2 = 3
rem = abs(v1)
print "Absulte value is ",rem

print "cmp(80,100): ",cmp(80,100)
print "cmp(180,100): ",cmp(180,100)
print "cmp(-80,100): ",cmp(-80,100)
print "cmp(80,-100): ",cmp(80,-100)

print "max(80,100,1000): ",max(80,100,1000)
print "max(-20,100,400): ",max(-20,100,400)
print "max(-80,-20,-10): ",max(-80,-20,-10)
print "max(0,100,-400): ",max(0,100,-400)

print "pow(10,2): ",pow(10,2)

print "squre root of 100 is :",math.sqrt(100)
