#!/usr/bin/python
#Basic program of for loop
for cntr in range(1,20,2):
	print cntr
for cntr in range(1,5):
	print cntr
for cntr in range(3):
	print cntr
for cntr in range(1,5):
	print cntr,
for cntr in range(20,1,-2):
	print cntr,
for cntr in range(-10,5):
	print cntr
else:
	print"The for loop is over"
for cntr in range(-10,5):
	print cntr,
for cntr in [0,3,5,7,9]:
	print cntr
