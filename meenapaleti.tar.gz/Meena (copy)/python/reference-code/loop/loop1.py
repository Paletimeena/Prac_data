#!/usr/bin/python
#Basic program of for loop
low = 10
high= 20


for cntr in range(low,high):
	print cntr,
print
for cntr in (0,3,5,7,9):
	print cntr,
