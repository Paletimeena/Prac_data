#!/usr/bin/python
operator=raw_input("""
Please enter the operator would you to complet
1.+ for addtion
2.- for subtraction
3.* for multipication
4./ for division
5.% for remendar
6.** for power
7.// for floatting formate """)
num1=input("\nPlease enter the 1st number\n")
num2=input("Please enter the 2nd number\n")
num3=input("Please enter the 3rd number\n")
op=input("Please enter the option as 2 or 3\n")
if op == 2:
	if operator == "+":
		res = num1num2
		print("{}+{} is".format(num1,num2))
	
