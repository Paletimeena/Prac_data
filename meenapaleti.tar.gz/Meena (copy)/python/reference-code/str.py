#!/usr/bin/python
#Basic program of strings.
str = "Hello India"
print str
print str[0]
print str[:5]
print str[5:]
print str[2:6]
print str * 2
print str + ",Good Evening"
print"Last word of the string is ",str[-1]
print "Thanks"

