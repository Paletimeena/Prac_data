#!/usr/bin/python

mylist = range(5)
print mylist
for index in mylist:
	print index	
