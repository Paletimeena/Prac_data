#!/usr/bin/python
num=int(raw_input("Please enter the number in binary formate\n")
)

print num

result = bin(num)
print result
