#!/usr/bin/python
for letter in 'python':
	if letter=='h':
		pass
		print"This is pass letter"
	print"Current letter:",letter
print"Thanks"
