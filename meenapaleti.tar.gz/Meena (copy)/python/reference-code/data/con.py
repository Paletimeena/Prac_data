#!/usr/bin/python

str1=(raw_input("Please enter the string\n"))

res = int(str1,10)
print "Integer formate of given string is ",res

