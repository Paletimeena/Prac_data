#!/usr/bin/python
val=int(raw_input("Please enter the number\n"))
val1=raw_input("Please enter the number\n")
val2=float(raw_input("Please enter the number\n"))
res= val+val2
print"Result is ",res
print"Enter name is "+val1+"CHATURVEDI"
