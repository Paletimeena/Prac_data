#!/usr/bin/python

var1 = 1
var2 = 10
print var1,var2
del var1
print var2
del var2
print var1,var2

