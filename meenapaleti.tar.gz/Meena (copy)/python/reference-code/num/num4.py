#!/usr/bin/python
num=input("Please enter the hexadecimal number\n")

res=bin(num)
print "Binary formate of given number is :",res

res=oct(num)
print "Octal formate of given number is :",res

res=int(num)
print "Decimal formate of given number is :",res
print "Thanks!"
