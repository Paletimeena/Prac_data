#!/usr/bin/python
num=(input("Please enter the octal number\n"))


res=bin(num)
print "Binary formate of given number is :",res

res=int(num)
print "Decimal formate of given number is :",res

res=hex(num)
print "Hexadecimal formate of given number is :",res
print "Thanks!"
