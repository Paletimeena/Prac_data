#!/usr/bin/python
num=int(raw_input("Please enter the decimal number\n"))

res=bin(num)
print "Binary formate of given number is :",res

res=oct(num)
print "Octal formate of given number is :",res

res=hex(num)
print "Hexadecimal formate of given number is :",res
print "Thanks!"
