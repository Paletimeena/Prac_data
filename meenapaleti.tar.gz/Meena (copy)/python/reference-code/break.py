#!/usr/bin/python
while True:
	mystring=raw_input("please enter somthing:")
	if mystring=="quit":
		break;
	print"Length of the string is",len(mystring)
print"Done"
