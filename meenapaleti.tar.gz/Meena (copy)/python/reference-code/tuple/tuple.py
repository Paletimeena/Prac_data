#!/usr/bin/python
#Basic tset progam of tuple.

str = "Hello India"
mytuple = (10, 20, 30, "RAj",50)
mytinytuple = (15,25, "Aman")
print str
print mytuple
print mytinytuple
print mytuple[0]
print mytuple[:5]
print mytuple[5:]
print mytuple[3:]
print mytuple[2:4]
print mytuple * 2
print mytuple + mytinytuple
#mylist[4] = 40 # It's generating the error
print mytuple
print "Thanks"

