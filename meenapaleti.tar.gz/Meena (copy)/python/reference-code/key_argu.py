#!/usr/bin/python
# Function defination here

def printinfo(name,age):
	"This prints a passed string into this function" 
	print "NAME",name
	print "AGE",age
	return
#Now you can call the function
printinfo(age=50,name="miki")
printinfo(age=[1,2,3,4],name="miki")
printinfo(50,"miki") #this is not a right way
















