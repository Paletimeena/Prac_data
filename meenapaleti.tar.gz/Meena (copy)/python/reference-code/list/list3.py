#!/usr/bin/python
#Basic program of list.

list1 = [10, 20, 30, "RAj",50]
list2 = [15,25, "Aman"]
list1.append(list2)
print "Update list is ", list1
