#!/usr/bin/python

dict = {}
dict['one'] = "This is one"
dict[2] = "This is two"

tinydict = {'name':"John",'cod':6734,'dept':"sales"}

print "First element of dictionary is ",dict['one']
print "Second element of dictionary is ",dict[2]
print "Complete dictionary is ",tinydict

print "All key of the tinydict is ",tinydict.keys()
print "All values of the tinydict is ",tinydict.values()

mydict_keys=dict.keys()
print "All keys of dict is ",mydict_keys

mydict_values=dict.values()
print "All values of dict is ",mydict_values

