#!/usr/bin/python
#Basic tset progam Dictinory.

str = "Hello India"
dict = {'Name':"RAHUL","Age":32,"EMPID":839}
print str
print dict
print dir(dict)
print type(dict)
print dict.keys()
print dict.values()
print "Thanks"

