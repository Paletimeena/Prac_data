#!/usr/bin/python
# Function defination here

def changeme(str):
	"This is call by refrence"
	str="RAJ CHATURVEDI" 
	print "string inside the function: ",str
	return
#Now you can call the function
str="RAHUL CHATURVEDI"
changeme(str)
print "string outside the function: ",str















