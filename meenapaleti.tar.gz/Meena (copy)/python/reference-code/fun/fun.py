#!/usr/bin/python
# Function defination here

def printme(str):
	"This prints a passed string into this function" #for documention purpose
	print str
	print str
	print str
	print str
	print str
	print str
	print str
	print str
	print str
	return
#Now you can call the function
printme("ABCDEFGHIj")
printme("abcdefghij")















