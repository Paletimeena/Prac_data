#!/usr/bin/python
# Function defination here

def changeme(mytuple):
	"This is call by value" 
	print "Value inside the function: ",mytuple
	return
#Now you can call the function
mytuple=(10,20,30)
changeme(mytuple)
print "Value outside the function: ",mytuple















